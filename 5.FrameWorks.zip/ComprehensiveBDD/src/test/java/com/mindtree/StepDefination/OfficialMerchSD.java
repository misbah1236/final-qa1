package com.mindtree.StepDefination;

import io.cucumber.java.en.*;

public class OfficialMerchSD {
	
	@Given("Open Big Small Website {string} for Official Merch")
	public void open_big_small_website_for_official_merch(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	@Then("Click on  Official Merchandise drop down section")
	public void click_on_official_merchandise_drop_down_section() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	@Then("Select {string} from dropdown from Official merch")
	public void select_from_dropdown_from_official_merch(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	@Then("select {string} of your choice from selected item")
	public void select_of_your_choice_from_selected_item(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	@Then("Select {string} and add to cart from official merch page")
	public void select_and_add_to_cart_from_official_merch_page(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}
	@Then("If cart page is Displayed Close it from official merch page")
	public void if_cart_page_is_displayed_close_it_from_official_merch_page() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

}
